/*
 * Initialization script for Grid Photo Gallery
 */
jQuery(function($){
	"use strict";

	
});

